import logger from './logger';

const { Sequelize } = require('sequelize');


function connect(){
    const sequelize = new Sequelize('gestock', 'root', '', {
        host: 'localhost',
        dialect: 'mysql'
      });
    
      try {
        sequelize.authenticate();
        logger.info('Connexion a la base de donnée .');
      } catch (error) {
        logger.error('Unable to connect to the database:', error);
      }
}
export default connect;