import UserModel from "../models/utilisateur.model";
const { Sequelize } = require('sequelize');
import { Request, Response } from "express";
import { omit } from "lodash";
import { loginInterface, UserInterface } from "../interface/user.interface";

export async function createuser(value:UserInterface) {
   
        console.log("valeur recu"+ JSON.stringify(value))
        var newUser = UserModel.create(
          value
        );
  
      return newUser
      
  
}
export async function loginuser(value:loginInterface) {
    console.log(value)
    const finduser= UserModel.findOne({
    where: {email: value.email}
})
    return finduser;
}
export async function finduse(value:any) {
 const val = await UserModel.findOne({
        where: { email: value}
      })
      console.log(val)
      return val
}
export async function getallusers() {

        const user = await UserModel.findAll(); 
        return user;

     
}
export async function deleteUserid(id:number) {
  
        const user = await UserModel.destroy({
            where:{
                id:id
            }
        });
        return id;

}
export async function getbyId(id:number) {
 
        const user = await UserModel.findByPk(id);
        return user;

   
}
export async function updated(id:number, value:UserInterface) {
   const data = await UserModel.update(value,{
        where:{
            id: id
        }
    });
    return data;
}