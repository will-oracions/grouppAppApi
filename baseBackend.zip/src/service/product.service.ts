import ProductModel from "../models/product.models";
const { Sequelize } = require('sequelize');
import { Request, Response } from "express";
import { omit } from "lodash";
import { ProductInterface } from "../interface/product.interface";


export async function createproduct(value:ProductInterface) {

    try{
        const data = await ProductModel.create(value);
        return data.toJSON();

     } catch(e:any){
        throw new Error(e);
     } 
}
export async function getallproduct() {
    try{
        const data = await ProductModel.findAll();
        return data;

     } catch(e:any){
        throw new Error(e);
     } 
}
export async function deleteproductid(id:number) {
    try{
        const data = await ProductModel.destroy({
            where:{
                id:id
            }
        });
        return id;

     } catch(e:any){
        throw new Error(e);
     } 
}
export async function getproductbyId(id:number) {
    try{
        const data = await ProductModel.findByPk(id);
        return data;

     } catch(e:any){
        throw new Error(e);
     } 
}
export async function updatedproduct(id:number, value:ProductInterface) {
   try{ const data = await ProductModel.update(value,{
        where:{
            id: id
        }
    });
    return data;
} catch(e:any){
    throw new Error(e);
 } 
}