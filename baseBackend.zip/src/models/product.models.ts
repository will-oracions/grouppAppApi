const { Sequelize, Model, DataTypes } = require("sequelize");
const sequelize = new Sequelize("sqlite::memory:");

const ProducModel = sequelize.define("product", {
    noms: DataTypes.TEXT,
    prix_unitaire: DataTypes.NUMBER,
    quantite: DataTypes.NUMBER,
    unite: DataTypes.TEXT,
    reference: DataTypes.TEXT,
},
{
    freezeTableName: true,
    timestamps: true
}
);

(async () => {
  await sequelize.sync({ force: true });
  // Code here
})();
module.exports = ProducModel;
export default ProducModel;