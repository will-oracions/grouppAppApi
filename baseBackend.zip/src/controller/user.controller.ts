import { Request, Response } from "express";
import { omit } from "lodash";
import UserModel from "../models/utilisateur.model";
import { createuser, getallusers,deleteUserid,getbyId,updated, loginuser, finduse } from "../service/user.service";
import logger from "../utils/logger";
const { Sequelize } = require('sequelize');
import bcrypt from "bcrypt";
var util = require('../utils/jwt.utils')

export async function Adduser(
    req: Request,
    res: Response
){
    
      var noms = req.body.name;
      var email = req.body.email;
      var password = req.body.password;
      if(noms == null || email == null || password == null){
        return res.status(400).json({'error':'parametre manquants'})
    }
    finduse(email)
    .then(function(userFound){
      if(!userFound){
        bcrypt.hash(password, 5, function(err:any, bcryptedPassword:any){
          var value = {
            "email":email,
            "password":bcryptedPassword,
            "name":noms
          };
          createuser(value)
          .then(function(newUser:any){
            return res.status(201).json({
              'userId': newUser.id
            })
          })
          .catch(function(err){
            return res.status(500).json({'error':"impossible d'ajouter l'utilisateur"})
          })
        })
      }else{
        return res.status(409).json({'error':"l'utilisateur existe"})
      }
      
    })
    .catch(function(err){
      return res.status(500).json({'error':"impossible de vérifier l'utilisateur"})
    })
 
  


 

};
export async function Login(
    req: Request,
    res: Response
) {
  var email = req.body.email;
var password = req.body.password;

if(email == null || password == null){
  return res.status(400).json({'error':'parametre manquants'})
}
loginuser(req.body).then(function(finduser){
  if (finduser!=null){
    bcrypt.compare(password, finduser.password, function(errBycrypt, resBycrypt){
       if(resBycrypt){
           return res.status(201).json({'userId':finduser.id, 'token':util.generateTokenUser(finduser)}) 
       }else{
        return res.status(500).json({'error':"password Invalid"})
       }
    })

}else{
  return res.status(500).json({'error':"l'utilisateur n'existe pas dans la BD"})}
})
  
}
export async function updateUser(   
    req: Request,
    res: Response
){
  
        updated(parseInt(req.params.id),req.body)
        .then(function(allUser){
          return res.status(201).json(allUser)
        })
        .catch(function(err){
          return res.status(500).json({'error':"impossible de mettre a jpur l'utilisateurs"})
        })
       
   
}
export async function deleteUser(   
    req: Request,
    res: Response
){
    deleteUserid(parseInt(req.params.id))
    .then(function(deluser){
      return res.status(201).json(deluser)
    })
    .catch(function(err){
      return res.status(500).json({'error':"impossible de supprimer l'utilisateurs"})
    })  

}
export async function getUser(   
    req: Request,
    res: Response
){
     getallusers()
        .then(function(alluser){
          return res.status(201).json(alluser)
        })
        .catch(function(err){
          return res.status(500).json({'error':"impossible de retouner la liste des utilisateurs"})
        }) 
}
export async function getUserId(   
    req: Request,
    res: Response
){
  
       getbyId(parseInt(req.params.id))
       .then(function(userId){
        return res.status(201).json(userId)
      })
      .catch(function(err){
        return res.status(500).json({'error':"impossible de retouner la liste des utilisateurs"})
      })  
      

}
