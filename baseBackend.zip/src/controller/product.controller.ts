import { Request, Response } from "express";
import { omit } from "lodash";
import { createproduct, deleteproductid, getallproduct, getproductbyId, updatedproduct } from "../service/product.service";
import logger from "../utils/logger";
const { Sequelize } = require('sequelize');

export async function AddProduct(
    req: Request,
    res: Response
){
    try {
        const data = await createproduct(req.body);
        return res.status(200).json(data);
      } catch (e: any) {
        logger.error(e);
        return res.status(409).send(e.message);
      }
};
export async function updatProduct(   
    req: Request,
    res: Response
){
    try {
        const data = await updatedproduct(parseInt(req.params.id),req.body);
        return res.status(200).json(data);
      } catch (e: any) {
        logger.error(e);
        return res.status(409).send(e.message);
      }

}
export async function deleteProduct(   
    req: Request,
    res: Response
){
    try {
        const data = await deleteproductid(parseInt(req.params.id));
        return  res.status(200).json(data);
      } catch (e: any) {
        logger.error(e);
        return res.status(409).send(e.message);
      }

}
export async function getProdut(   
    req: Request,
    res: Response
){
    try {
        const data = await getallproduct();
        return res.status(200).json(data);
      } catch (e: any) {
        logger.error(e);
        return res.status(409).send(e.message);
      }

}
export async function getProductId(   
    req: Request,
    res: Response
){
    try {
        const data = await getproductbyId(parseInt(req.params.id));
        return  res.status(200).json(data);
      } catch (e: any) {
        logger.error(e);
        return res.status(409).send(e.message);
      }

}
