import { Express } from "express";
import { AddProduct, deleteProduct, getProductId, getProdut, updatProduct } from "../controller/product.controller";
import validateResource from '../middleware/validateResource'
import { CreateProductSchema } from "../schema/produits.schema";
function product(app: Express){
  
  /**
  * @swagger
  * '/api/product':
  *  get:
  *     tags:
  *      - Product
  *     descriptions: Get all product
  *     responses:
  *         200:
  *             description: all product
  */
  app.get('/api/product', getProdut)

  /**
  * @swagger
  * '/api/product/{id}':
  *  get:
  *     tags:
  *      - Product
  *     descriptions: Get product by Id
  *     parameters:
  *       - in: path
  *         name: id
  *         required: true
  *         description: ID Obligatoire
  *         schema:
  *          type: integer
  *     responses:
  *         200:
  *             description: Get product by Id
  */
  app.get('/api/product/:id', getProductId)
     /**
   * @swagger
   * '/api/product':
   *  post:
   *     tags:
   *     - Product
   *     summary: Register a product
   *     requestBody:
   *      required: true
   *      content:
   *        application/json:
   *           schema:
   *              $ref: '#/components/schemas/CreateProductInput'
   *     responses:
   *      200:
   *        description: Success
   *        content:
   *          application/json:
   *            schema:
   *              $ref: '#/components/schemas/CreateProductResponse'
   *      409:
   *        description: Conflict
   *      400:
   *        description: Bad request
   */
 app.post('/api/product', validateResource(CreateProductSchema), AddProduct)
     /**
   * @swagger
   * '/api/product/{id}':
   *  put:
   *     tags:
   *     - Product
   *     summary: Update  product
   *     description: Update product
   *     parameters:
   *          - in: path
   *            name: id
   *            required: true
   *            description: ID Obligatoire
   *            schema:
   *             type: integer
   *     requestBody:
   *      required: true
   *      content:
   *        application/json:
   *           schema:
   *              $ref: '#/components/schemas/CreateProductInput'
   *     responses:
   *      200:
   *        description: Success
   *        content:
   *          application/json:
   *            schema:
   *              $ref: '#/components/schemas/CreateProductResponse'
   *      409:
   *        description: Conflict
   *      400:
   *        description: Bad request
   */
  app.put('/api/product/:id', updatProduct)
 /**
  * @swagger
  * '/api/product/{id}':
  *  delete:
  *     tags:
  *      - Product
  *     descriptions: Delete product
  *     parameters:
  *       - in: path
  *         name: id
  *         required: true
  *         description: ID Obligatoire
  *         schema:
  *         type: integer
  *     responses:
  *         200:
  *             description: Delete product
  */
 app.delete('/api/product/:id', deleteProduct)
}
export default product;