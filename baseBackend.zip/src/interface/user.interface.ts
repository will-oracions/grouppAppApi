export interface UserInterface {
    email: string;
    name: string;
    password: string;
  }
  export interface loginInterface{
    email: string;
    password: string;
  }