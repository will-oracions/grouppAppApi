export interface ProductInterface {
    email: string;
    name: string;
    password: string;
  }