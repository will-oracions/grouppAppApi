import express from "express";
import config from "config";
import connect from './utils/connect';
import logger from './utils/logger';
import users from './routes/users.routes'
import swaggerDocs from "./utils/swagger";
import product from "./routes/product.routes";
var cors = require('cors')
const port = config.get<number>('port');
const app = express();
app.use(express.json())
app.use(cors({
    origin:'*'
}))

app.listen(port, async ()=>{
    logger.info(`Server is running at http://localhost:${port}`);

    await connect();


    users(app);
    product(app)
    swaggerDocs(app, port);
});